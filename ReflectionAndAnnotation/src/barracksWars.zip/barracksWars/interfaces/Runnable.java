package barracksWars.interfaces;

public interface Runnable {
	void run();
}
