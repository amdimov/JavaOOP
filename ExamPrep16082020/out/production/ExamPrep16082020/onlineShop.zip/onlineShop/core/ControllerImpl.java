package onlineShop.core;

import onlineShop.core.interfaces.Controller;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.computers.DesktopComputer;
import onlineShop.models.products.computers.Laptop;
import onlineShop.models.products.peripherals.Headset;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.Map;

import static onlineShop.common.constants.ExceptionMessages.*;
import static onlineShop.common.constants.OutputMessages.*;

public class ControllerImpl implements Controller {
    private Map<Integer, Computer> computers;
    private Map<Integer, Peripheral> peripherals;

    public ControllerImpl() {
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        if (computers.containsKey(id)){
            throw new IllegalArgumentException(EXISTING_COMPUTER_ID);
        }
        if (computerType == null || computerType.trim().isEmpty()){
            throw new IllegalArgumentException(INVALID_COMPUTER_TYPE);
        }
        Computer computer = null;
        switch (computerType){
            case "Laptop":
                computer = new Laptop(id, manufacturer, model, price);
                break;
            case "DesktopComputer":
                computer = new DesktopComputer(id, manufacturer, model, price);
                break;
        }
        computers.put(id, computer);
        return String.format(ADDED_COMPUTER, id);
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer
            , String model, double price, double overallPerformance, String connectionType) {
        if (peripherals.containsKey(id)){
            throw new IllegalArgumentException(EXISTING_COMPUTER_ID);
        }
        if (peripheralType == null || peripheralType.trim().isEmpty()){
            throw new IllegalArgumentException(INVALID_COMPUTER_TYPE);
        }
        Peripheral peripheral = null;
        switch (peripheralType){
            case "Headset":
                peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
                break;
            case "Keyboard":
                break;
            case "Monitor":
                break;
            case "Mouse":
                break;
        }
        peripherals.put(id, peripheral);
        return String.format(ADDED_COMPUTER, id);
    }

    @Override
    public String removePeripheral(String peripheralType, int computerId) {
        return null;
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        return null;
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        return null;
    }

    @Override
    public String buyComputer(int id) {
        return null;
    }

    @Override
    public String BuyBestComputer(double budget) {
        return null;
    }

    @Override
    public String getComputerData(int id) {
        return null;
    }
}
