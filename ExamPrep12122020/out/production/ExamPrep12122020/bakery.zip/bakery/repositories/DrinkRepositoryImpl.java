package bakery.repositories;

import bakery.repositories.interfaces.DrinkRepository;

import java.util.Collection;
import java.util.HashSet;

public class DrinkRepositoryImpl<Drink> implements DrinkRepository {
    private Collection<Drink> models;

    public DrinkRepositoryImpl() {
        this.models = new HashSet<>();
    }

    @Override
    public Object getByNameAndBrand(String drinkName, String drinkBrand) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
