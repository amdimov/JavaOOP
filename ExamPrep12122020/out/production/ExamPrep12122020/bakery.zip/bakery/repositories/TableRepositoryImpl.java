package bakery.repositories;

import bakery.repositories.interfaces.TableRepository;

import java.util.Collection;
import java.util.HashSet;

public class TableRepositoryImpl<Table> implements TableRepository {
    private Collection<Table> models;

    public TableRepositoryImpl() {
        this.models = new HashSet<>();
    }
    @Override
    public Object getByNumber(int number) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
