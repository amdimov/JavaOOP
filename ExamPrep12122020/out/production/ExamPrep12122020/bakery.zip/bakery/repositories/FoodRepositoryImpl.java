package bakery.repositories;

import bakery.repositories.interfaces.FoodRepository;

import java.util.Collection;
import java.util.HashSet;

public class FoodRepositoryImpl<Food> implements FoodRepository {
    private Collection<Food> models;

    public FoodRepositoryImpl() {
        this.models = new HashSet<>();
    }
    @Override
    public Object getByName(String name) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
