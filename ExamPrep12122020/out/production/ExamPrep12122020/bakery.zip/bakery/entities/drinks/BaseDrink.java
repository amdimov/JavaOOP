package bakery.entities.drinks;

import bakery.entities.drinks.interfaces.Drink;

public abstract class BaseDrink implements Drink {
    private String name;
    private int portion;
    private double price;
    private String brand;

    protected BaseDrink(String name, int portion, double price, String brand) {
        setName(name);
        setPortion(portion);
        setPrice(price);
        setBrand(brand);
    }

    //TODO validation
    private void setName(String name) {
        this.name = name;
    }

    private void setPortion(int portion) {
        this.portion = portion;
    }

    private void setPrice(double price) {
        this.price = price;
    }

    private void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getPortion() {
        return 0;
    }

    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public String getBrand() {
        return null;
    }

    //Returns a String with information about each drink. The returned String must be in the following format:
    //"{current drink name} {current brand name} - {current portion}ml - {current price - formatted to the second digit}lv"
    @Override
    public String toString() {
        return super.toString();
    }
}
