public interface Person extends Creaturable {
    int getAge();
}
