public interface Machinable {
    String getModel();
}
