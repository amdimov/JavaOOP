public interface Creaturable {
    String getName();
}
