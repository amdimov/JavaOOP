package viceCity.models.neighbourhood;

import viceCity.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GangNeighbourhood implements Neighbourhood {
    private Player mainPlayer;
    private List<Player> civilPlayers;
    public GangNeighbourhood(){
        civilPlayers = new ArrayList<>();
    }
    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {

    }
}
