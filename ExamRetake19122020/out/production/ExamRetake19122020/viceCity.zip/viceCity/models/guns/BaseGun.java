package viceCity.models.guns;

import viceCity.models.players.BasePlayer;

public abstract class BaseGun implements Gun {
    private String name;
    private int bulletsPerBarrel;
    private int totalBullets;
    private boolean canFire;
    protected BaseGun(String name, int bulletsPerBarrel, int totalBullets){
        setName(name);
        setBulletsPerBarrel(bulletsPerBarrel);
        setTotalBullets(totalBullets);
    }

    private void setTotalBullets(int totalBullets) {

    }

    private void setBulletsPerBarrel(int bulletsPerBarrel) {

    }

    private void setName(String name) {
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getBulletsPerBarrel() {
        return 0;
    }

    @Override
    public boolean canFire() {
        return false;
    }

    @Override
    public int getTotalBullets() {
        return 0;
    }


}
