package viceCity.models.players;

public class MainPlayer extends BasePlayer {
    public MainPlayer() {
        super("Tommy Vercetti", 100);
    }
}
