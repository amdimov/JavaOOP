package viceCity.models.players;

import viceCity.models.guns.Gun;
import viceCity.repositories.GunRepository;
import viceCity.repositories.interfaces.Repository;

public abstract class BasePlayer implements Player {
    private String name;
    private int lifePoints;
    private Repository<Gun> gunRepository;

    public BasePlayer(String name, int lifePoints) {
        setName(name);
        setLifePoints(lifePoints);
        this.gunRepository = new GunRepository();
        //TODO - gunRepository
    }

    private void setLifePoints(int lifePoints) {
        //TODO Problem 2
        //o	If the name is null or whitespace, throw a NullPointerException	with message
        //"Player's name cannot be null or a whitespace!"
        //o	All names are unique
    }

    private void setName(String name) {
        //TODO Problem 2
        //o	The health of а player
        //o	If the health is below 0, throw an IllegalArgumentException with message
        //"Player life points cannot be below zero!"
    }


    //TODO Overrides Problem 2
    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getLifePoints() {
        return 0;
    }

    @Override
    public boolean isAlive() {
        return this.lifePoints > 0;
    }

    @Override
    public Repository<Gun> getGunRepository() {
        return null;
    }

    @Override
    public void takeLifePoints(int points) {

    }
}
