package P04PizzaCalories;

public class Main {
}
